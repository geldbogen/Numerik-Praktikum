import tkinter as tk
import math
from tracemalloc import start
import numpy as np
delta=0.00000001
point=np.array([-3.0,10.0 ])

def twentynine(input_array,params):
    l=params[0]
    output=np.array([])
    sum=np.sum(input_array)
    for x in input_array:
        value=x-math.exp(l*math.cos(x*sum))
        output=np.append(output,value)
    return output
g=lambda x: twentynine(x,[1])

def four_dot_nine(input_array,params):
    p=params[0]
    s=np.sum(input_array)
    x=input_array
    output=np.array([x[0]+x[3]-3,2*x[0]+x[1]+x[3]+x[6]+x[7]+x[8]+2*x[9]-p,2*x[1]+2*x[4]+x[5]+x[6]-8,
    2*x[2]+x[8]-4*p,
    x[0]*x[4]-0.193*x[1]*x[3],
    (x[5]**2)*x[0]-0.67444*(10**(-5))*x[1]*x[3]*s,
    (x[6]**2)*x[3]-0.1189*(10**(-4))*x[0]*x[1]*s,
    x[7]*x[3]-0.1799*(10**(-4))*x[0]*s,
    ((x[8]*x[3])**2)-0.4644*(10**(-7))*(x[0]**2)*x[2]*s,
    x[9]*(x[3]**2)-0.3846*(10**(-4))*(x[0]**2)*s])
    return output

def Brusselator(input_array,params):
    x=input_array[0]
    y=input_array[1]
    a=params[0]
    b=params[1]
    return np.array([(a-(b+1)*x+(x**2)*y),b*x-(x**2)*y])
f=lambda x: Brusselator(x,[1,1])


def apply_partial_diff(f,delta,point,direction):
    transformed_array=point.copy()
    transformed_array[direction]+=delta
    output=np.add(f(transformed_array),float(-1)*f(point))
    output=output/delta
    # print("jo")
    return np.array([output])

def compute_jacobian(f,delta,point):
    d=0
    output=apply_partial_diff(f,delta,point,d)
    while True:
        try:
            d+=1
            output=np.append(output,apply_partial_diff(f,delta,point,d),axis=0)
        except IndexError:
            break
    output=np.transpose(output)
    return output


def easy_newton(f,delta,start_point):
    jac=compute_jacobian(f,delta,start_point)
    inv_jac=np.linalg.inv(jac)
    x=start_point
    y=0
    while True:
        y=x-np.dot(inv_jac,f(x))
        print("der aktuelle Punkt ist")
        print(y)
        if np.amax((x-y)**2)<=0.00000001:
            break
        x=y
    print("die antwort ist \n")
    print(y)
    print("f(x) ist ungefähr \n")
    print(f(y))
    return y 

def normal_newton(f,delta,start_point):
    x=start_point
    y=0
    while True:
        jac=compute_jacobian(f,delta,x)
        inv_jac=np.linalg.inv(jac)
        y=x-np.dot(inv_jac,f(x))
        print("der aktuelle Punkt ist")
        print(y)
        if np.amax((x-y)**2)<=0.000001:
            break
        x=y
    print("die antwort ist \n")
    print(y)
    print("f(x) ist ungefähr \n")
    print(f(y))
    return y 

def quasi_newton(f,delta,start_point):
    jac=compute_jacobian(f,delta,start_point)
    inv_jac=np.linalg.inv(jac)
    dimension=inv_jac.shape[0] 
    
    # x=start_point
    # y=start_point-np.dot(inv_jac,f(start_point))
    # z=0
    # A_inv_x=inv_jac
    # delta_bar_x=0
    # delta_x=(-1)*np.dot(inv_jac,f(x))
    # delta_bar_y=(-1)*np.dot(inv_jac,y)
    
    # delta_y=(delta_bar_y/(1-((np.dot(delta_bar_y,delta_x))/(np.dot(delta_x,delta_x)))))

    # A_inv_y=np.dot((np.identity(dimension)+(np.outer(delta_y,delta_x)/(np.dot(delta_x,delta_x)))),A_inv_x)

    # A_inv_z=0
    # delta_z=0
    # delta_bar_z=0

    delta_x=(-1)*np.dot(inv_jac,f(start_point))
    A_x=inv_jac
    x=start_point

    while True:
        y=x+delta_x
        print("der aktuelle Punkt ist")
        print(y)
        delta_bar_y=(-1)*np.dot(A_x,f(y))
        alpha=np.dot(delta_bar_y,delta_x)/np.dot(delta_x,delta_x)
        delta_y=delta_bar_y/(1-alpha)
        matrix=np.identity(dimension)+(np.outer(delta_y,delta_x)*(1/np.dot(delta_x,delta_x)))
        A_y=np.dot(matrix,A_x)
        if np.amax(delta_x**2)<=(0.001)**2:
            break
        x=y
        delta_x=delta_y
        A_x=A_y





    

    # while True:
    #     z=y+delta_y
    #     delta_bar_z=np.dot(((-1)*A_inv_y),f(z))
    #     alpha=(1-((np.dot(delta_bar_z,delta_y))/(np.dot(delta_y,delta_y))))
    #     delta_z=((delta_bar_z)*(1/alpha))

    #     matrix=(np.identity(dimension)+(np.outer(delta_z,delta_y)/(np.dot(delta_y,delta_y))))
    #     A_inv_z=np.dot(matrix,A_inv_y)
        
        
    #     delta_y=delta_z
    #     y=z
    #     A_inv_y=A_inv_z
    
    
    print("die antwort ist \n")
    print(y)
    print("f(x) ist ungefähr \n")
    print(f(y))
    return y

def gogogo():
    global procedure_var
    global which_var
    if which_var.get()==0:
        p=[float(Elambda.get())]
        f=lambda x: twentynine(x,p)
    if which_var.get()==1:
        p=Elambda.get().splilt(" ")
        p=[float(x) for x in p]
        f= lambda x: Brusselator(x,p)
    if which_var.get()==2:
        p=[float(Elambda.get())]
        f=lambda x: four_dot_nine(x,p)

    
    start_point_string=Estart.get()
    start_point=start_point_string.split(" ")
    start_point=[float(x) for x in start_point]
    start_point=np.array(start_point)

    if procedure_var.get()==0:
        easy_newton(f,0.00001,start_point)
    if procedure_var.get()==1:
        normal_newton(f,0.00001,start_point)
    if procedure_var.get()==2:
        quasi_newton(f,0.00001,start_point)
    


root=tk.Tk()
which_var=tk.IntVar()

SLabel=tk.Label(root,text="Welche Aufgabe soll bearbeitet werden")
SLabel.grid(column=0,row=0)

Radio1=tk.Radiobutton(root,text="Beispiel 4.30",variable=which_var,value=0)
Radio2=tk.Radiobutton(root,text="Beispiel 4.31",variable=which_var,value=1)
Radio3=tk.Radiobutton(root,text="Aufgabe 4.9",variable=which_var,value=2)
Radio1.grid(column=0,row=1)
Radio2.grid(column=0,row=2)
Radio3.grid(column=0,row=3)

procedure_var=tk.IntVar()

PLabel=tk.Label(root,text="Welches Verfahren soll angewendet werden?")
PLabel.grid(column=1,row=0)

PRadio1=tk.Radiobutton(root,text="vereinfachtes Newton-Verfahren",variable=procedure_var,value=0)
PRadio2=tk.Radiobutton(root,text="normales Newton-Verfahren",variable=procedure_var,value=1)
PRadio3=tk.Radiobutton(root,text="Quasi-Newton-Verfahren",variable=procedure_var,value=2)

PRadio1.grid(column=1,row=1)
PRadio2.grid(column=1,row=2)
PRadio3.grid(column=1,row=3)

lambda_label=tk.Label(root,text="wie groß soll der Parameter sein?\n (bei Beispiel 4.31 zwei Parameter mit Leerzeichen getrennt eingeben)")
lambda_label.grid(column=2,row=0)

Elambda=tk.Entry(root)
Elambda.grid(column=2,row=1)


start_label=tk.Label(root,text="die Startkoordinaten (mit Leerzeichen getrennt)")
start_label.grid(column=2,row=2)
Estart=tk.Entry(root)
Estart.grid(column=2,row=3)

myButton=tk.Button(root,text="Los",command=gogogo)
myButton.grid(row=4,column=1)



root.mainloop()

quit()